import React from "react";
import logo from "./logo.svg";
import "./App.css";
import Pizza from "./components/pizza/Pizza";

function App() {
  return <Pizza />;
}

export default App;
