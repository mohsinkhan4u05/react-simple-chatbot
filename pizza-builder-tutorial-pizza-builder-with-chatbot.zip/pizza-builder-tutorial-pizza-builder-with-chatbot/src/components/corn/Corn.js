import React from "react";

function Corn() {
  return (
    <div>
      <div className="corns">
        <div className="corn-1" />
        <div className="corn-2" />
        <div className="corn-3" />
        <div className="corn-4" />
        <div className="corn-5" />
        <div className="corn-6" />
        <div className="corn-7" />
        <div className="corn-8" />
        <div className="corn-9" />
        <div className="corn-10" />
        <div className="corn-11" />
      </div>

      <div className="corns">
        <div className="corn-11" />
      </div>
    </div>
  );
}

export default Corn;
